"""Build a standalone VimTip using the embedded script resource supported by AHK v2."""
import argparse
import ctypes
from ctypes import wintypes
from pathlib import Path
import re
import shutil

def build(base, main, output):
    source = main.read_text(encoding="utf-8-sig")
    def include(match):
        return (main.parent / match[1]).read_text(encoding="utf-8-sig")
    source = re.sub(r"(?m)^#Include ([A-Za-z]+\.ahk)$", include, source)
    if re.search(r"(?im)^#include\b", source):
        raise ValueError("Unresolved include directive")
    data = source.replace("\r\n", "\n").replace("\n", "\r\n").encode("utf-8")
    api = ctypes.WinDLL("kernel32", use_last_error=True)
    def bind(name, result, args):
        f = getattr(api, name)
        f.restype, f.argtypes = result, args
        return f
    ptr, uint, word, boolean = ctypes.c_void_p, wintypes.DWORD, wintypes.WORD, wintypes.BOOL
    begin = bind("BeginUpdateResourceW", ptr, [wintypes.LPCWSTR, boolean])
    update = bind("UpdateResourceW", boolean, [ptr, ptr, ptr, word, ptr, uint])
    end = bind("EndUpdateResourceW", boolean, [ptr, boolean])
    temp = output.with_suffix(".build.exe")
    shutil.copyfile(base, temp)
    try:
        handle = begin(str(temp), False)
        if not handle:
            raise ctypes.WinError(ctypes.get_last_error())
        buf = ctypes.create_string_buffer(data)
        if not update(handle, 10, 1, 0x409, buf, len(data)):
            error = ctypes.get_last_error()
            end(handle, True)
            raise ctypes.WinError(error)
        if not end(handle, False):
            raise ctypes.WinError(ctypes.get_last_error())
        load = bind("LoadLibraryExW", ptr, [wintypes.LPCWSTR, ptr, uint])
        lib = load(str(temp.resolve()), None, 2)
        if not lib:
            raise ctypes.WinError(ctypes.get_last_error())
        try:
            res = bind("FindResourceW", ptr, [ptr, ptr, ptr])(lib, 1, 10)
            size = bind("SizeofResource", uint, [ptr, ptr])(lib, res)
            loaded = bind("LoadResource", ptr, [ptr, ptr])(lib, res)
            addr = bind("LockResource", ptr, [ptr])(loaded)
            if not addr or size != len(data) or ctypes.string_at(addr, size) != data:
                raise RuntimeError("Embedded script verification failed")
        finally:
            bind("FreeLibrary", boolean, [ptr])(lib)
        temp.replace(output)
        print(f"{output}: embedded {len(data)} verified bytes")
    finally:
        if temp.exists():
            temp.unlink()

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("base", type=Path, help="AutoHotkey v2 x64 executable")
    parser.add_argument("--output", type=Path, default=Path(__file__).with_name("VimTip.exe"))
    args = parser.parse_args()
    build(args.base, Path(__file__).parent / "src" / "VimTip.ahk", args.output)
