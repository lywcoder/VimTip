"""Compare the original and VimTip event handlers with the same deterministic OS input traces."""
import argparse
import re
import subprocess
import tempfile
from pathlib import Path

def handlers(source):
    start = source.index("~*LShift Up::")
    end = source.index("; ================== 3. IME")
    source = source[start:end]
    source = source.replace("~*LShift Up::\n~*RShift Up::", "TestShift()")
    source = source.replace("*CapsLock::", "TestCaps()").replace("~*LCtrl Up::", "TestCtrl()")
    source = source.replace("~Esc::SwitchToEnglish()", "TestEsc() => SwitchToEnglish()").replace("~Esc::{", "TestEsc() {")
    source = re.sub(r"(?m)^#HotIf.*$", "", source)
    source = source.replace("A_TickCount","sim.ms").replace("A_PriorKey","sim.prior")
    source = source.replace("GetKeyState(", "FakeState(").replace("KeyWait ", "FakeWait ")
    source = source.replace("SendEvent ", "FakeEvent ").replace("Send ", "Trace ").replace("Sleep ", "FakeSleep ")
    source = source.replace("SendLevel 0", 'Trace("level0")').replace("SetCapsLockState()", 'Trace("cleanup")')
    source = source.replace('DllCall("user32\\GetForegroundWindow", "Ptr")', "sim.fg")
    source = re.sub(r'return \(DllCall\("user32\\GetAsyncKeyState".*', 'return sim.held = "LShift" || sim.held = "RShift"', source)
    return source

def compare(runtime, original):
    here = Path(__file__).resolve().parent
    harness = (here / "trace-fixture.ahk").read_text(encoding="utf-8")
    with tempfile.TemporaryDirectory() as folder:
        root = Path(folder)
        traces = []
        for name, path in [("original", original),("vimtip", here.parent / "src/Core.ahk")]:
            script = root / (name + ".ahk")
            log = root / (name + ".txt")
            script.write_text(harness + "\n" + handlers(path.read_text(encoding="utf-8-sig")),encoding="utf-8-sig")
            subprocess.run([str(runtime),"/ErrorStdOut=UTF-8",str(script),str(log)],check=True,timeout=20)
            traces.append(log.read_text(encoding="utf-8-sig").splitlines())
        assert len(traces[0]) == len(traces[1]) == 22
        for baseline, current in zip(*traces):
            if baseline != current:
                raise AssertionError((baseline, current))
            print("PASS",current)
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("runtime",type=Path)
    parser.add_argument("original",type=Path)
    args = parser.parse_args()
    compare(args.runtime.resolve(),args.original.resolve())
