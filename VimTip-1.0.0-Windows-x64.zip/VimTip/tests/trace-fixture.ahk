global CapsCtrlDown := false, SuppressShiftHud := false, KeyboardActionSerial := 0
global CAPS_TAP_MS := 260, Pref := {TapMs: 260, ImeHud: true, CapsHud: true, TapEnglish: true, EscEnglish: true}
global sim := {}
logPath := A_Args[1]
for c in [
    ["tap", "Caps", "CapsLock", 75], ["boundary", "Caps", "CapsLock", 260], ["long", "Caps", "CapsLock", 261],
    ["copy", "Caps", "c", 70], ["paste", "Caps", "v", 90], ["mouse", "Caps", "LButton", 60],
    ["caps-then-shift", "Caps", "LShift", 50], ["left-shift-first", "Caps", "CapsLock", 30, "LShift"],
    ["right-shift-first", "Caps", "CapsLock", 30, "RShift"], ["already-locked", "Caps", "CapsLock", 30, "RShift", 1],
    ["physical-control-held", "Caps", "CapsLock", 50, "LCtrl"], ["alt-held", "Caps", "CapsLock", 50, "Alt"],
    ["ctrl-up-during-caps", "Ctrl", "LCtrl", 0], ["cleanup", "Cleanup", "CapsLock", 0],
    ["shift-chinese", "Shift", "LShift", 0], ["shift-english", "Shift", "RShift", 0],
    ["shift-unknown", "Shift", "LShift", 0], ["shift-retry", "Shift", "RShift", 0],
    ["shift-focus-changed", "Shift", "LShift", 0], ["shift-other-key", "Shift", "x", 0],
    ["shift-ctrl", "Shift", "LShift", 0, "LCtrl"], ["physical-esc", "Esc", "Escape", 0]] {
    CapsCtrlDown := c[2] = "Ctrl" || c[2] = "Cleanup"
    SuppressShiftHud := false
    sim := {id:c[1], prior:c[3], duration:c[4], held:c.Length>=5 ? c[5] : "", lock:c.Length>=6 ? c[6] : 0,
        ms:0, fg:101, reads:0, cap:c[2]="Caps" || c[2]="Ctrl", trace:""}
    switch c[2] {
        case "Caps": TestCaps()
        case "Shift": TestShift()
        case "Ctrl": TestCtrl()
        case "Cleanup": CleanupKeyboard()
        case "Esc": TestEsc()
    }
    FileAppend(c[1] "|" sim.trace "|" CapsCtrlDown "|" SuppressShiftHud Chr(10), logPath, "UTF-8")
}
ExitApp()
Trace(v) => sim.trace .= v ";"
FakeState(key, mode) {
    if mode = "T"
        return sim.lock
    if key = "CapsLock"
        return sim.cap
    if key = "Ctrl"
        return sim.held = "LCtrl"
    return sim.held = key
}
FakeWait(key) {
    sim.ms += sim.duration
    sim.cap := false
}
FakeSleep(ms) {
    if ms = 10
        sim.held := ""
    if ms = 60 && sim.id = "shift-focus-changed"
        sim.fg := 202
}
FakeEvent(keys) {
    Trace(keys)
    sim.lock := !sim.lock
}
GetImeState() {
    sim.reads++
    Trace("read")
    if sim.id = "shift-unknown" || (sim.id = "shift-retry" && sim.reads = 1)
        return -1
    return sim.id = "shift-english" ? 0 : 1
}
SetImeState(state) {
    Trace("ime=" state)
    return true
}
ShowMacHud(s) => Trace("hud=" s)
ReportAction(args*) => 0
ImeLabel(s) => s
