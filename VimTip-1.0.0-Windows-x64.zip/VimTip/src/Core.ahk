; ================== 1. Shift：显示中/英文状态 ==================
~*LShift Up::
~*RShift Up::
{
    global SuppressShiftHud, CapsCtrlDown, KeyboardActionSerial

    ; 整个 Shift+CapsLock 周期仅显示 A/a；两侧 Shift 都松开后再清除标记。
    if SuppressShiftHud {
        if !GetKeyState("LShift", "P") && !GetKeyState("RShift", "P")
            SuppressShiftHud := false
        return
    }

    ; Caps 映射产生的 Ctrl 不是物理 Ctrl，也必须排除；鼠标组合不弹输入法 HUD。
    if CapsCtrlDown || GetKeyState("CapsLock", "P")
        return

    ; 如果按 Shift 的过程中按过其他键，不认为是单按 Shift
    if (A_PriorKey != "LShift" && A_PriorKey != "RShift")
        return

    ; 忽略 Ctrl+Shift / Alt+Shift / Win+Shift 等组合
    if GetKeyState("Ctrl", "P") || GetKeyState("Alt", "P")
        || GetKeyState("LWin", "P") || GetKeyState("RWin", "P")
        || GetKeyState("Shift", "P")
        return

    ; 允许输入法先处理 Shift 松开。等待期间切换窗口时，不向新窗口显示旧提示。
    actionBefore := KeyboardActionSerial
    foregroundBefore := DllCall("user32\GetForegroundWindow", "Ptr")
    Sleep 60
    if (actionBefore != KeyboardActionSerial)
        return
    imeState := GetImeState()
    if (imeState = -1) {
        Sleep 60
        imeState := GetImeState()
    }

    ; 无法可靠查询状态时不显示猜测结果
    if (actionBefore = KeyboardActionSerial && foregroundBefore = DllCall("user32\GetForegroundWindow", "Ptr")) {
        ReportAction("单按 Shift", foregroundBefore, , ImeLabel(imeState))
        if (imeState != -1 && Pref.ImeHud)
            ShowMacHud(imeState = 1 ? "中" : "英")
    }
}

; ================== 2. CapsLock：短按/长按/组合 ==================
; Shift 必须先按下；CapsLock 先按下再按 Shift 仍是 Ctrl+Shift 组合。
; 大小写在 CapsLock 与所有 Shift 都松开后提交，一次组合只切换一次。
*CapsLock::
{
    global SuppressShiftHud, CapsCtrlDown, KeyboardActionSerial
    appBefore := DllCall("user32\GetForegroundWindow", "Ptr")
    threshold := Pref.TapMs
    KeyboardActionSerial++ ; 取消此前尚未显示的 Shift 输入法提示

    if GetKeyState("LShift", "P") || GetKeyState("RShift", "P") || ShiftIsDownAsync() {
        SuppressShiftHud := true

        ; 设置 CapsLock 会产生原生锁定按键事件，Shift 仍按着时可能被 IME 当作组合键。
        ; 等完整的物理组合结束，不发送虚假的 Shift Up，也不进入 Ctrl/Esc 分支。
        KeyWait "CapsLock"
        while GetKeyState("LShift", "P") || GetKeyState("RShift", "P") || ShiftIsDownAsync()
            Sleep 10

        ToggleNativeCapsLock()
        SuppressShiftHud := false
        letter := GetKeyState("CapsLock", "T") ? "A" : "a"
        ReportAction("Shift → CapsLock", appBefore, , "大小写  " letter)
        if Pref.CapsHud
            ShowMacHud(letter) ; 读取实际状态，不伪造结果
        return
    }

    otherModifier := GetKeyState("Ctrl", "P") || GetKeyState("Alt", "P")
        || GetKeyState("LWin", "P") || GetKeyState("RWin", "P")
    pressTime := A_TickCount

    ; 立即提供 Ctrl，快速 Caps+C/V 也有效；短按是否发 Esc 在释放后判断。
    CapsCtrlDown := true
    try {
        Send "{Blind}{LCtrl DownR}"
        KeyWait "CapsLock"
    } finally {
        ReleaseCapsCtrl()
    }

    ; 普通 Caps 分支不修改大写锁定，大小写仅由专用分支管理。
    elapsed := A_TickCount - pressTime
    wasTap := A_PriorKey = "CapsLock"
    action := CapsAction(otherModifier, wasTap, elapsed, threshold)
    if (action = "轻点 CapsLock") {
        Send "{Esc}"
        result := Pref.TapEnglish ? EnglishResult() : "切英文已关闭"
        ReportAction(action, appBefore, elapsed, "已发送 Esc  ·  " result)
    } else {
        ReportAction(action, appBefore, elapsed, "已释放映射 Ctrl")
    }
}

ToggleNativeCapsLock() {
    ; 只发送一次原生 CapsLock。不能根据线程中暂时未刷新的读数立即重发，
    ; 否则第二次按键会把第一次的切换抵消。
    SendLevel 0
    SendEvent "{Blind}{CapsLock}"
    Sleep 30
}

CapsAction(otherModifier, wasTap, elapsed, threshold) {
    if otherModifier || !wasTap
        return "Ctrl 组合"
    return elapsed <= threshold ? "轻点 CapsLock" : "长按 CapsLock"
}

ShiftIsDownAsync() {
    return (DllCall("user32\GetAsyncKeyState", "Int", 0x10, "Short") & 0x8000) != 0
}

ReleaseCapsCtrl() {
    global CapsCtrlDown
    if !CapsCtrlDown
        return
    CapsCtrlDown := false
    ; 用户还按着实体左 Ctrl 时，让它自己的 Key Up 负责释放。
    if !GetKeyState("LCtrl", "P")
        Send "{Blind}{LCtrl Up}"
}

; 实体左 Ctrl 在 Caps 仍按着时松开，继续维持由 Caps 提供的 Ctrl。
#HotIf CapsCtrlDown
~*LCtrl Up::
{
    global CapsCtrlDown
    if CapsCtrlDown && GetKeyState("CapsLock", "P")
        Send "{Blind}{LCtrl DownR}"
}

#HotIf

CleanupKeyboard(*) {
    ReleaseCapsCtrl()
    ; 退出/重载时移除本脚本的强制属性，保留当时的大小写状态。
    SetCapsLockState()
}

; 鼠标动作由已安装的鼠标钩子计入 A_PriorKey，无需注册全局滚轮热键。

; 物理 Esc 保留原始功能，同时尝试切英文
~Esc::{
    appBefore := DllCall("user32\GetForegroundWindow", "Ptr")
    result := Pref.EscEnglish ? EnglishResult() : "切英文已关闭"
    ReportAction("物理 Esc", appBefore, , result)
}

EnglishResult() {
    return SetImeState(0) ? "已读回英文" : "未确认切换"
}

; ================== 3. IME 状态获取 / 设置 ==================
; 从当前前台窗口及其焦点控件找到默认 IME 窗口。
GetDefaultImeWnd() {
    foregroundHwnd := DllCall("user32\GetForegroundWindow", "Ptr")
    if !foregroundHwnd || !DllCall("user32\IsWindow", "Ptr", foregroundHwnd, "Int")
        return 0

    targetHwnd := foregroundHwnd
    try {
        focusHwnd := ControlGetFocus("ahk_id " foregroundHwnd)
        if focusHwnd
            targetHwnd := focusHwnd
    }

    if (targetHwnd = foregroundHwnd) {
        threadId := DllCall("user32\GetWindowThreadProcessId", "Ptr", foregroundHwnd, "Ptr", 0, "UInt")
        infoSize := (A_PtrSize = 8) ? 72 : 48
        guiThreadInfo := Buffer(infoSize, 0)
        NumPut("UInt", infoSize, guiThreadInfo, 0)

        if DllCall("user32\GetGUIThreadInfo", "UInt", threadId, "Ptr", guiThreadInfo, "Int") {
            focusOffset := (A_PtrSize = 8) ? 16 : 12
            focusHwnd := NumGet(guiThreadInfo, focusOffset, "Ptr")
            if focusHwnd
                targetHwnd := focusHwnd
        }
    }

    imeHwnd := DllCall("imm32\ImmGetDefaultIMEWnd", "Ptr", targetHwnd, "Ptr")
    if (!imeHwnd && targetHwnd != foregroundHwnd)
        imeHwnd := DllCall("imm32\ImmGetDefaultIMEWnd", "Ptr", foregroundHwnd, "Ptr")

    if !imeHwnd {
        try {
            processId := WinGetPID("ahk_id " foregroundHwnd)
            imeHwnd := WinExist("ahk_class IME ahk_pid " processId)
        }
    }
    return imeHwnd
}

; 用超时消息避免 IDE/浏览器无响应时卡住热键线程。
SendImeCommand(imeHwnd, command, param := 0) {
    messageResult := 0
    try {
        success := DllCall("user32\SendMessageTimeoutW",
            "Ptr", imeHwnd,
            "UInt", 0x0283,     ; WM_IME_CONTROL
            "Ptr", command,
            "Ptr", param,
            "UInt", 0x0002,    ; SMTO_ABORTIFHUNG
            "UInt", 150,
            "Ptr*", &messageResult,
            "Ptr")
        return success ? messageResult : -1
    } catch {
        return -1
    }
}

; 返回 1=中文，0=英文，-1=不可查询
GetImeState() {
    imeHwnd := GetDefaultImeWnd()
    if !imeHwnd
        return -1
    result := SendImeCommand(imeHwnd, 0x0005) ; IMC_GETOPENSTATUS
    return (result = 0 || result = 1) ? result : -1
}

; 请求设置 0=英文；某些现代 TSF 输入法可能不支持传统 IMM32 接口
SetImeState(state) {
    imeHwnd := GetDefaultImeWnd()
    if !imeHwnd
        return false
    if (SendImeCommand(imeHwnd, 0x0006, state ? 1 : 0) = -1)
        return false
    ; 消息投递成功不等于输入法已接受设置；返回真正读回的状态。
    return SendImeCommand(imeHwnd, 0x0005) = (state ? 1 : 0)
}
