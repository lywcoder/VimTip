ShowMacHud(displayText, duration := unset) {
    static hudGuis := []
    static hudTexts := []
    static hideTimer := ""

    ; 初始化统一的隐藏回调
    if !hideTimer {
        hideTimer := (*) => HideAllHuds()
        HideAllHuds() {
            for guiObj in hudGuis
                try guiObj.Hide()
        }
    }

    monCount := MonitorGetCount()

    ; 动态扩容 GUI 实例数组，确保每个显示器都有独立的 HUD
    while (hudGuis.Length < monCount) {
        guiObj := Gui("+AlwaysOnTop -Caption +ToolWindow +E0x20", "VimTip · 屏幕提示")
        guiObj.BackColor := "1E1E1E"
        guiObj.MarginX := 25
        guiObj.MarginY := 18
        guiObj.SetFont("s30 bold cWhite", "Microsoft YaHei UI")
        txtObj := guiObj.AddText("Center w90", "")
        WinSetTransparent(215, guiObj)

        hudGuis.Push(guiObj)
        hudTexts.Push(txtObj)
    }

    ; 重置隐藏计时器
    SetTimer(hideTimer, 0)

    ; 遍历所有显示器，计算中心并显示
    Loop monCount {
        idx := A_Index
        hudTexts[idx].Value := displayText

        hudGuis[idx].Show("NoActivate AutoSize Hide")
        hudGuis[idx].GetPos(,, &guiW, &guiH)

        ; 获取当前显示器的边界坐标（适配负坐标与多分辨率屏幕）
        MonitorGet(idx, &mLeft, &mTop, &mRight, &mBottom)
        posX := mLeft + ((mRight - mLeft) - guiW) // 2
        posY := mTop + ((mBottom - mTop) - guiH) // 2

        hudGuis[idx].Show("NoActivate X" posX " Y" posY)

        ; 钉在最高 Z 轴层级，避免被全屏窗口覆盖
        DllCall("SetWindowPos", "Ptr", hudGuis[idx].Hwnd, "Ptr", -1, "Int", 0, "Int", 0, "Int", 0, "Int", 0, "UInt", 0x0053)
    }

    ; 按配置的时长隐藏
    SetTimer(hideTimer, -(duration ?? Pref.HudMs))
}
