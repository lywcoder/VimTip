OldScriptWindow() {
    for hwnd in WinGetList("ahk_class AutoHotkey") {
        try {
            title := WinGetTitle(hwnd)
            if InStr(title, LegacyScript " - AutoHotkey") = 1
                return hwnd
        }
    }
    return 0
}

ResolveRunningLegacy() {
    hwnd := OldScriptWindow()
    if !hwnd
        return true
    if MsgBox("检测到原 config.ahk 正在运行。是否退出这一个旧脚本并启动 VimTip？原脚本文件和登录启动项会保留。", "切换到 VimTip", "YesNo Icon? Default2") != "Yes"
        return false
    try {
        PostMessage(0x0010, 0, 0, , "ahk_id " hwnd)
        if WinWaitClose("ahk_id " hwnd, , 3)
            return true
    }
    MsgBox("旧脚本仍在运行。请从旧脚本托盘菜单退出后，再打开 VimTip。", "VimTip")
    return false
}

OwnLink() => StartupDir "\VimTip.lnk"
BackupLink() => SettingsDir "\previous-startup.lnk"
BackupNameFile() => SettingsDir "\previous-startup-name.txt"

ReadLink(path) {
    FileGetShortcut(path, &target, , &args, &description)
    return {Target: target, Args: args, Note: description}
}

IsOurLink(path) {
    try return ReadLink(path).Note = "VimTip Logon v1"
    return false
}

LegacyLinks() {
    items := []
    Loop Files StartupDir "\*.lnk", "F" {
        try {
            if ReadLink(A_LoopFileFullPath).Target = LegacyScript
                items.Push(A_LoopFileFullPath)
        }
    }
    return items
}

SetStartup(enabled, interactive := true) {
    link := OwnLink(), backup := BackupLink(), stamp := BackupNameFile()
    if FileExist(link) && !IsOurLink(link)
        throw Error("启动文件夹里已有同名快捷方式，请先检查 VimTip.lnk。")
    if !enabled {
        if FileExist(link)
            FileDelete(link)
        return
    }
    items := LegacyLinks()
    if items.Length > 1 || (items.Length && FileExist(backup))
        throw Error("发现多个或重复的旧启动入口，请先检查启动文件夹。")
    old := items.Length ? items[1] : ""
    if old && interactive && MsgBox("已找到原 config.ahk 的登录快捷方式。启用 VimTip 自启会把这个快捷方式备份，你可以在此页还原。继续吗？", "迁移登录启动项", "YesNo Icon?") != "Yes"
        return
    DirCreate(SettingsDir)
    moved := false
    try {
        if old {
            SplitPath(old, &name)
            f := FileOpen(stamp, "w", "UTF-8")
            try f.Write(name)
            finally f.Close()
            FileMove(old, backup)
            moved := true
        }
        if A_IsCompiled
            FileCreateShortcut(A_ScriptFullPath, link, A_ScriptDir, "--tray", "VimTip Logon v1")
        else
            FileCreateShortcut(A_AhkPath, link, A_ScriptDir, '"' A_ScriptFullPath '" --tray', "VimTip Logon v1")
    } catch as err {
        if moved
            FileMove(backup, old)
        throw err
    }
}

RestoreLegacy() {
    backup := BackupLink(), stamp := BackupNameFile()
    if !FileExist(backup) || !FileExist(stamp)
        throw Error("未找到可还原的旧启动项。")
    name := Trim(FileRead(stamp, "UTF-8"))
    if !RegExMatch(name, "i)^[^\\/:*?`"<>|]+\.lnk$")
        throw Error("备份名称无效。")
    dest := StartupDir "\" name
    if FileExist(dest)
        throw Error("启动文件夹中已存在原名称，请先检查。")
    if FileExist(OwnLink()) && !IsOurLink(OwnLink())
        throw Error("当前的 VimTip.lnk 不属于本程序。")
    FileMove(backup, dest)
    try SetStartup(false)
    catch as err {
        FileMove(dest, backup)
        throw err
    }
    FileDelete(stamp)
}
