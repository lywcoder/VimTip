Defaults() {
    return {TapMs: 260, HudMs: 650, TapEnglish: 1, EscEnglish: 1, ImeHud: 1, CapsHud: 1}
}

ValidNumber(value, low, high) {
    return IsInteger(value) && value >= low && value <= high
}

LoadPrefs() {
    global Pref
    loaded := Defaults()
    for key, fallback in loaded.OwnProps() {
        raw := IniRead(SettingsFile, "Options", key, fallback)
        low := key = "TapMs" ? 50 : key = "HudMs" ? 100 : 0
        high := key = "TapMs" ? 1000 : key = "HudMs" ? 5000 : 1
        loaded.%key% := ValidNumber(raw, low, high) ? Integer(raw) : fallback
    }
    Pref := loaded
}

PersistPrefs(candidate) {
    global Pref
    DirCreate(SettingsDir)
    tmp := SettingsFile "." DllCall("GetCurrentProcessId") ".tmp"
    data := "[Options]`r`n"
    for key, value in candidate.OwnProps()
        data .= key "=" value "`r`n"
    try {
        file := FileOpen(tmp, "w", "UTF-16")
        try file.Write(data)
        finally file.Close()
        FileMove(tmp, SettingsFile, true)
        Pref := candidate
    } finally {
        if FileExist(tmp)
            FileDelete(tmp)
    }
}

AppForWindow(hwnd) {
    try return WinGetProcessName("ahk_id " hwnd)
    return "未知应用"
}

ImeLabel(state) {
    return state = 1 ? "中文" : state = 0 ? "英文" : "未知"
}

ReportAction(action, hwnd, elapsed := unset, detail := "") {
    global LastEvent
    duration := IsSet(elapsed) ? "  ·  " elapsed " ms" : ""
    LastEvent := action duration "  ·  " detail "`n" AppForWindow(hwnd) "    " FormatTime(, "HH:mm:ss")
    if Panel
        Ui.Event.Text := LastEvent
}
