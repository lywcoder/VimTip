#Requires AutoHotkey v2.0
#SingleInstance Ignore
#MaxThreadsPerHotkey 1
#MaxThreadsBuffer false
;@Ahk2Exe-SetName VimTip
;@Ahk2Exe-SetDescription VimTip 键位与输入法助手
;@Ahk2Exe-SetVersion 1.0.0.0
DetectHiddenWindows True
Suspend(true)
global CapsCtrlDown := false, SuppressShiftHud := false, KeyboardActionSerial := 0
global Pref := Defaults(), Panel := 0, Ui := {}, LastEvent := "等待一次按键操作"
global SettingsDir := A_AppData "\VimTip", SettingsFile := SettingsDir "\settings.ini"
global StartupDir := A_Startup, LegacyScript := EnvGet("USERPROFILE") "\config.ahk"
global PausePending := false
if (A_Args.Length >= 1 && A_Args[1] = "--self-test") {
    if (A_Args.Length != 2)
        ExitApp(2)
    SelfTest(A_Args[2])
    ExitApp(0)
}
if !ResolveRunningLegacy()
    ExitApp()
LoadPrefs()
InstallKeybdHook()
InstallMouseHook()
SetCapsLockState()
SetCapsLockState "Off"
SetStoreCapsLockMode false
OnExit(CleanupKeyboard)
A_HotkeyInterval := 0
Suspend(false)
MakeTray()
if !(A_Args.Length && A_Args[1] = "--tray")
    OpenPanel()
return

#Include Core.ahk
#Include Hud.ahk
#Include Settings.ahk
#Include Startup.ahk
#Include Panel.ahk
#Include SelfTest.ahk
