MakeTray() {
    A_IconTip := "VimTip · 键位与输入法"
    A_TrayMenu.Delete()
    A_TrayMenu.Add("打开设置", OpenPanel)
    A_TrayMenu.Default := "打开设置"
    A_TrayMenu.ClickCount := 2
    A_TrayMenu.Add("暂停键位映射", ToggleMapping)
    A_TrayMenu.Add("登录时启动", ToggleStartup)
    A_TrayMenu.Add()
    A_TrayMenu.Add("退出 VimTip", RequestExit)
    RefreshStatus()
}

OpenPanel(*) {
    global Panel, Ui
    if !Panel {
        g := Gui(, "VimTip · 键位与输入法")
        g.BackColor := "F6F7F5"
        g.SetFont("s10 c253730", "Microsoft YaHei UI")
        g.SetFont("s21 bold")
        g.AddText("x22 y12 w340 h44", "VimTip")
        g.SetFont("s10 norm")
        Ui.State := g.AddText("x350 y28 w243 h24 Right", "")
        tabs := g.AddTab3("x20 y68 w580 h397", ["键位与测试", "屏幕提示", "常规"])
        tabs.UseTab(1)
        g.AddText("x40 y114 w390 h22", "CapsLock 短按阈值（50–1000 ms）")
        Ui.Tap := g.AddEdit("x448 y110 w118 h28 Number")
        Ui.TapEn := g.AddCheckbox("x40 y151 w258", "轻点 CapsLock 后尝试切英文")
        Ui.EscEn := g.AddCheckbox("x306 y151 w265", "按物理 Esc 后尝试切英文")
        g.AddText("x40 y196 w530 h46", "按住 CapsLock 可用作左 Ctrl。先按 Shift 再按 CapsLock 切换大小写；先按 CapsLock 再按 Shift 可用作 Ctrl+Shift。")
        g.AddText("x40 y251 w530 h22", "试打区   ·   可在此选择文本，测试复制与粘贴")
        Ui.Test := g.AddEdit("x40 y278 w534 h69 Multi WantReturn", "VimTip 键位测试")
        g.AddText("x40 y366 w530 h25", "最近一次识别")
        Ui.Event := g.AddText("x40 y394 w534 h54", LastEvent)
        tabs.UseTab(2)
        Ui.Ime := g.AddCheckbox("x40 y118 w525", "单按 Shift 后显示输入法状态「中 / 英」")
        Ui.Caps := g.AddCheckbox("x40 y160 w525", "切换系统大小写后显示「A / a」")
        g.AddText("x40 y216 w390 h23", "屏幕提示时长（100–5000 ms）")
        Ui.Hud := g.AddEdit("x448 y212 w118 h28 Number")
        g.AddText("x40 y263 w525 h45", "提示会在每个显示器中央出现。预览使用上方填写的时长。")
        g.AddButton("x40 y322 w132 h36", "预览「中」").OnEvent("Click", (*) => Preview("中"))
        g.AddButton("x184 y322 w132 h36", "预览「A」").OnEvent("Click", (*) => Preview("A"))
        tabs.UseTab(3)
        Ui.Logon := g.AddCheckbox("x40 y116 w529", "登录 Windows 后在托盘启动 VimTip")
        Ui.Logon.OnEvent("Click", ToggleStartup)
        g.AddText("x40 y156 w526 h40", "启动项的更改立即生效。旧快捷方式迁移后，可在这里还原。")
        Ui.Restore := g.AddButton("x40 y207 w180 h34", "还原旧版登录启动项")
        Ui.Restore.OnEvent("Click", RestoreClick)
        Ui.Pause := g.AddButton("x235 y207 w160 h34", "暂停键位映射")
        Ui.Pause.OnEvent("Click", ToggleMapping)
        g.AddText("x40 y270 w530 h25", "本地配置")
        g.AddEdit("x40 y301 w530 h30 ReadOnly", SettingsFile)
        g.AddButton("x40 y363 w180 h34", "恢复默认参数").OnEvent("Click", ResetClick)
        tabs.UseTab()
        Ui.Note := g.AddText("x22 y486 w395 h30", "")
        g.AddButton("x456 y478 w144 h37", "应用设置").OnEvent("Click", ApplyClick)
        g.OnEvent("Close", (*) => g.Hide())
        Panel := g
        FillFields(Pref)
    }
    RefreshStatus()
    Panel.Show("w620 h530")
}

FillFields(p) {
    Ui.Tap.Value := p.TapMs
    Ui.Hud.Value := p.HudMs
    Ui.TapEn.Value := p.TapEnglish
    Ui.EscEn.Value := p.EscEnglish
    Ui.Ime.Value := p.ImeHud
    Ui.Caps.Value := p.CapsHud
}

CollectFields() {
    if !ValidNumber(Ui.Tap.Value, 50, 1000) || !ValidNumber(Ui.Hud.Value, 100, 5000)
        throw Error("请输入范围内的整数：短按 50–1000，提示 100–5000。")
    return {TapMs: Integer(Ui.Tap.Value), HudMs: Integer(Ui.Hud.Value),
        TapEnglish: Ui.TapEn.Value, EscEnglish: Ui.EscEn.Value, ImeHud: Ui.Ime.Value, CapsHud: Ui.Caps.Value}
}

ApplyClick(*) {
    try {
        PersistPrefs(CollectFields())
        Ui.Note.Text := "已保存，从下次按键开始生效"
    } catch as err {
        Ui.Note.Text := err.Message
    }
}

ResetClick(*) {
    FillFields(Defaults())
    Ui.Note.Text := "已填入默认值，点击“应用设置”保存"
}

Preview(letter) {
    if ValidNumber(Ui.Hud.Value, 100, 5000)
        ShowMacHud(letter, Integer(Ui.Hud.Value))
    else
        Ui.Note.Text := "提示时长需为 100–5000 ms 的整数"
}

RefreshStatus() {
    msg := A_IsSuspended ? "键位映射已暂停" : "键位映射运行中"
    if PausePending
        msg := "等待当前组合结束"
    enabled := IsOurLink(OwnLink())
    if enabled
        A_TrayMenu.Check("登录时启动")
    else
        A_TrayMenu.Uncheck("登录时启动")
    if A_IsSuspended
        A_TrayMenu.Check("暂停键位映射")
    else
        A_TrayMenu.Uncheck("暂停键位映射")
    A_IconTip := "VimTip · " msg
    if Panel {
        Ui.State.Text := msg
        Ui.Logon.Value := enabled
        Ui.Restore.Enabled := FileExist(BackupLink()) != ""
        Ui.Pause.Text := A_IsSuspended ? "恢复键位映射" : "暂停键位映射"
    }
}

ToggleStartup(*) {
    try SetStartup(!IsOurLink(OwnLink()))
    catch as err
        MsgBox(err.Message, "登录时启动", "Icon!")
    RefreshStatus()
}

RestoreClick(*) {
    if MsgBox("还原 config.ahk 的登录快捷方式并关闭 VimTip 自启？下次登录起生效。", "还原旧版", "YesNo Icon? Default2") = "Yes" {
        try RestoreLegacy()
        catch as err
            MsgBox(err.Message, "还原旧版", "Icon!")
    }
    RefreshStatus()
}

ToggleMapping(*) {
    global PausePending
    if A_IsSuspended {
        Suspend(false)
    } else if PausePending {
        PausePending := false
        SetTimer(FinishPause, 0)
    } else {
        PausePending := true
        SetTimer(FinishPause, 25)
    }
    RefreshStatus()
}

FinishPause() {
    global PausePending, KeyboardActionSerial
    if CapsCtrlDown || GetKeyState("CapsLock", "P") || ShiftIsDownAsync() || SuppressShiftHud
        return
    SetTimer(FinishPause, 0)
    PausePending := false
    KeyboardActionSerial++
    Suspend(true)
    RefreshStatus()
}

RequestExit(*) {
    ExitApp()
}
