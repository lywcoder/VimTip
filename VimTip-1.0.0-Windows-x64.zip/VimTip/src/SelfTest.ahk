Check(ok, name) {
    if !ok
        throw Error(name)
}

SelfTest(root) {
    global StartupDir, SettingsDir, SettingsFile, LegacyScript
    Suspend(true)
    if FileExist(root)
        ExitApp(3)
    DirCreate(root)
    logFile := root "\result.txt"
    try {
        StartupDir := root "\Startup"
        SettingsDir := root "\Prefs"
        SettingsFile := SettingsDir "\settings.ini"
        LegacyScript := root "\config.ahk"
        DirCreate(StartupDir)
        LoadPrefs()
        Check(Pref.TapMs = 260 && Pref.HudMs = 650, "默认值")
        MakeTray()
        OpenPanel()
        Check(WinExist("ahk_id " Panel.Hwnd), "设置窗口")
        Ui.Tap.Value := "200"
        Ui.Hud.Value := "430"
        Ui.EscEn.Value := 0
        ApplyClick()
        LoadPrefs()
        Check(Pref.TapMs = 200 && Pref.HudMs = 430 && !Pref.EscEnglish, "设置落盘和重新读取")
        Ui.Tap.Value := "5"
        ApplyClick()
        Check(Pref.TapMs = 200, "越界输入")
        ResetClick()
        Check(Ui.Tap.Value = 260 && Pref.TapMs = 200, "恢复默认值草稿")
        IniWrite("malformed", SettingsFile, "Options", "HudMs")
        LoadPrefs()
        Check(Pref.HudMs = 650 && Pref.TapMs = 200, "损坏设置回退")
        Check(CapsAction(false, true, 260, 260) = "轻点 CapsLock", "短按边界")
        Check(CapsAction(false, true, 261, 260) = "长按 CapsLock", "长按边界")
        Check(CapsAction(false, false, 145, 260) = "Ctrl 组合", "快速组合优先")
        Check(CapsAction(true, true, 30, 260) = "Ctrl 组合", "实体修饰键优先")
        ReportAction("测试动作", Panel.Hwnd, 145, "测试")
        Check(InStr(Ui.Event.Text, "145 ms") && InStr(Ui.Event.Text, ".exe"), "事件显示")
        focusBefore := DllCall("user32\GetForegroundWindow", "Ptr")
        Preview("中")
        windows := WinGetList("VimTip · 屏幕提示 ahk_pid " DllCall("GetCurrentProcessId"))
        Check(windows.Length = MonitorGetCount(), "每屏一个 HUD")
        for hwnd in windows
            Check(DllCall("IsWindowVisible", "Ptr", hwnd), "HUD 可见")
        Check(DllCall("user32\GetForegroundWindow", "Ptr") = focusBefore, "HUD 保留焦点")
        Sleep 700
        for hwnd in windows
            Check(!DllCall("IsWindowVisible", "Ptr", hwnd), "HUD 定时隐藏")
        InstallKeybdHook()
        InstallMouseHook()
        ToggleMapping()
        Check(!A_IsSuspended, "恢复映射")
        ToggleMapping()
        Sleep 100
        Check(A_IsSuspended, "等待释放后暂停")
        Panel.Hide()
        OpenPanel()
        FileAppend("; fixture", LegacyScript)
        oldPath := StartupDir "\config.ahk - 快捷方式.lnk"
        FileCreateShortcut(LegacyScript, oldPath)
        SetStartup(true, false)
        Check(IsOurLink(OwnLink()) && FileExist(BackupLink()) && !FileExist(oldPath), "启动项迁移")
        shortcut := ReadLink(OwnLink())
        Check(InStr(shortcut.Args, "--tray"), "静默启动参数")
        SetStartup(false)
        Check(!FileExist(OwnLink()) && FileExist(BackupLink()), "关闭自启")
        SetStartup(true, false)
        RestoreLegacy()
        Check(FileExist(oldPath) && !FileExist(OwnLink()) && !FileExist(BackupLink()), "旧启动项还原")
        FileCreateShortcut(LegacyScript, OwnLink())
        rejected := false
        try SetStartup(false)
        catch
            rejected := true
        Check(rejected && FileExist(OwnLink()), "保护同名快捷方式")
        FileAppend("PASS: settings GUI, apply, validation, defaults, persistence, HUD, event view, tray, startup migration, disable, restore, collision guard.", logFile, "UTF-8")
    } catch as err {
        FileAppend("FAIL: " err.Message " at " err.File ":" err.Line "`n" err.Stack, logFile, "UTF-8")
        ExitApp(1)
    }
}
